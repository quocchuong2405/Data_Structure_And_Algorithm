#include "SymbolTable.h"

void SymbolTable::run(string filename)
{
    cout << "success";
}